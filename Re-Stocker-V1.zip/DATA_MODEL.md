# Data Model

Item: name, quantity, threshold, daily_use, last_purchase_date.
