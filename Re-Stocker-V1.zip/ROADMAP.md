# Roadmap

- [x] Planning structure
- [x] SQLite schema
- [x] Flutter starter
