daily_use: amount used per day
threshold: alert level
