# Use Cases

1. Add item
2. Track days left
3. Auto shopping list
