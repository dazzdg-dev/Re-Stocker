# UX Wireframes

Home → Low stock list → Add Item.
